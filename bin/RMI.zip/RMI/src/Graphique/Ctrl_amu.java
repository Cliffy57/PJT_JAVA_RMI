package RMI.src.Graphique;

import java.net.URL;
import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.util.ResourceBundle;

import RMI.src.Interface.AmuInterface;
import javafx.beans.value.ChangeListener;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;


public class Ctrl_amu implements Initializable {
	@FXML
	private Label valeur;
	@FXML
	private Button btn_un;
	@FXML
	private Button btn_deux;
	
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try
		{
			 try {
				    if (System.getSecurityManager() == null) {
				      System.setSecurityManager(new RMISecurityManager());
				    }
				  } catch (Exception e) {
				    System.out.println("TUE TOI " +e);
				  }
			int port=8000;
			AmuInterface obj = (AmuInterface)Naming.lookup("rmi://localhost:"+port+"/src");
			obj.Nombre();
			System.out.println(obj.ConsoleLog());
			obj.ChoixJoueur(1);
			System.out.println(obj.ConsoleLog());
			obj.ChoixJoueur(2);
			System.out.println(obj.ConsoleLog());
			obj.ChoixOrdi();
			System.out.println(obj.ConsoleLog());
		}
		catch(Exception e)
		{
			
			System.out.println("Erreur client AMU : "+e);
		}
	}
	
	public void joueur_action_un()
	{
		try
		{
		int port=8000;
		AmuInterface obj = (AmuInterface)Naming.lookup("rmi://localhost:"+port+"/src");
		obj.ChoixJoueur(1);
		}catch(Exception e) {
			System.out.println("E" +e);
		}
	}
	public void joueur_action_deux()
	{
		
	}
	

}
