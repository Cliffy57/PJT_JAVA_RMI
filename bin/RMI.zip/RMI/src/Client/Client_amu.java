package RMI.src.Client;

import java.rmi.Naming;

import RMI.src.Interface.*;

public class Client_amu {
	public static void main(String[] argv)
	{
		try
		{
			int port=8000;
			AmuInterface obj = (AmuInterface)Naming.lookup("rmi://localhost:"+port+"/src");
			obj.Nombre();
			System.out.println(obj.ConsoleLog());
			obj.ChoixJoueur(1);
			System.out.println(obj.ConsoleLog());
			obj.ChoixJoueur(2);
			System.out.println(obj.ConsoleLog());
			obj.ChoixOrdi();
			System.out.println(obj.ConsoleLog());
		}
		catch(Exception e)
		{
			
			System.out.println("Erreur client AMU : "+e);
		}
	}
}
