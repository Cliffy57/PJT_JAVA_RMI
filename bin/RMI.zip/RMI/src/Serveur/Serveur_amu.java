package RMI.src.Serveur;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;


import RMI.src.Interface.AmuImpl;

public class Serveur_amu {

	public static void main(String[] argv)
	{
		try
		{
			int port=8000;
		LocateRegistry.createRegistry(port);
		Naming.rebind("rmi://localhost:"+port+"/src", new AmuImpl());
			System.out.println("Statut du serveur AMU lanc� sur le port : "+port);
		}
		catch(Exception e)
		{
			
			System.out.println("Erreur serveur AMU : "+e);
		}
	}
}
