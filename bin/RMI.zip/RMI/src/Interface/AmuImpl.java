package RMI.src.Interface;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class AmuImpl extends UnicastRemoteObject implements AmuInterface{
	int  nb_amu = 0;
	int Min=5;
	int Max=20;
	
	public AmuImpl () throws RemoteException{
		super();	
	}

	@Override
	public String ConsoleLog() throws RemoteException {
			//Boucle

		String ctrl2 = "Valeur : " +nb_amu;
	
		return ctrl2;
	}

	

	@Override
	public int Nombre() throws RemoteException { //Nombre d'alu
		int nombreAleatoire = GenererAleatoire();
		if (nombreAleatoire % 2 == 0)nombreAleatoire = GenererAleatoire();
		
		return nb_amu = nombreAleatoire;
	}

	@Override
	public int ChoixOrdi() throws RemoteException {
		// TODO Auto-generated method stub
		//int retire_ordi =  1 + (int)(Math.random() * ((2-1)+1)); //L'ordi retire 1 ou 2
		
		return nb_amu = nb_amu - 1 + (int)(Math.random() * ((2-1)+1));
	}

	@Override
	public int DeterminePremierJoueur() throws RemoteException {
		// TODO Auto-generated method stub
		return 1 + (int)(Math.random() * ((2-1)+1)); //Renvoie 1 ou 2 , si 1 => Joueur sinon le serveur
	}
	
		//Permet de g�n�rer un nb al�atoire
	public int GenererAleatoire()
	{
		return Min + (int)(Math.random() * ((Max - Min) + 1));
	}

	@Override
	public int ChoixJoueur(int valeur_joue) throws RemoteException {
		// TODO Auto-generated method stub
		return nb_amu =  nb_amu - valeur_joue;
	}
	
	
	
	
	
}
