package RMI.src.Interface;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface AmuInterface extends Remote{
	public String ConsoleLog() throws RemoteException;
	public int ChoixJoueur(int valeur_joue) throws RemoteException; //CHoix du joueur entre 1 et 2
	public int Nombre() throws RemoteException; //Init le nb de d'anu
	public int ChoixOrdi() throws RemoteException; // CHoix de l'ordi entre un et deux (al�atoire)
	public int DeterminePremierJoueur() throws RemoteException; // Determine si le joueur et l'ordi qui joue en premier
}
